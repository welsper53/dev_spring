package com.vo;

public class Main {

	public static void main(String[] args) {
		DeptVO dvo = new DeptVO();
		//DeptVO dvo2 = new DeptVO(10,"개발부","서울");
		
	}

}
